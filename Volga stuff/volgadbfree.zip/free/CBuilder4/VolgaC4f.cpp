//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("VolgaC4f.res");
USEPACKAGE("vcl40.bpi");
USEUNIT("VolgaReg.pas");
USEUNIT("VolgaConst.pas");
USEUNIT("VolgaTbl.pas");
USEPACKAGE("vclx40.bpi");
USEPACKAGE("vcldb40.bpi");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
        return 1;
}
//---------------------------------------------------------------------------
