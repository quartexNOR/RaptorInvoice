// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'VolgaTbl.pas' rev: 4.00

#ifndef VolgaTblHPP
#define VolgaTblHPP

#pragma delphiheader begin
#pragma option push -w-
#include <VolgaConst.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Volgatbl
{
//-- type declarations -------------------------------------------------------
typedef Word *PWordBool;

#pragma option push -b-
enum TVolgaUpdStatus { vusUnmodified, vusModified, vusInserted, vusDeleted, vusAbsent };
#pragma option pop

#pragma option push -b-
enum TVolgaLoadMode { lmClear, lmFile, lmClone, lmStream };
#pragma option pop

#pragma option push -b-
enum TVolgaFieldType { vftUnknown, vftSmallInt, vftInteger, vftLargeInt, vftBoolean, vftDouble, vftCurrency, 
	vftDate, vftTime, vftDateTime, vftAutoInc, vftSmallStr, vftString, vftBlob, vftMemo, vftFmtMemo, vftGraphic 
	};
#pragma option pop

#pragma option push -b-
enum TVolgaBatchMode { vbmAppend, vbmAppendUpdate, vbmCopy, vbmCopyDef };
#pragma option pop

#pragma option push -b-
enum VolgaTbl__1 { vsoCaseInsensitive, vsoDescendSort, vsoInsertInOrder };
#pragma option pop

typedef Set<VolgaTbl__1, vsoCaseInsensitive, vsoInsertInOrder>  TVolgaSortOptions;

#pragma option push -b-
enum VolgaTbl__2 { savAutoBackup, savSlowMode, savSortOnIndex };
#pragma option pop

typedef Set<VolgaTbl__2, savAutoBackup, savSortOnIndex>  TVolgaSaveOptions;

typedef AnsiString VolgaTbl__3[17];

#pragma pack(push, 4)
struct TVolgaRecord
{
	char *Data;
	char *OldData;
	void *RecordData;
	TVolgaUpdStatus Status;
	int Size;
} ;
#pragma pack(pop)

typedef TVolgaRecord *PVolgaRecord;

#pragma pack(push, 4)
struct TVolgaField
{
	AnsiString Name;
	AnsiString Origin;
	Word DataSize;
	Word Size;
	int Offset;
	AnsiString KeyValue;
	TVolgaFieldType DataType;
	Classes::TAlignment Align;
	AnsiString DefValue;
	AnsiString Description;
} ;
#pragma pack(pop)

typedef TVolgaField *PVolgaField;

#pragma option push -b-
enum TKeyIndex { kiIndex, kiSearch, kiRangeStart, kiRangeEnd };
#pragma option pop

struct TKeyBuffer;
typedef TKeyBuffer *PKeyBuffer;

#pragma pack(push, 1)
struct TKeyBuffer
{
	char *Data;
	TKeyIndex Kind;
	Classes::TList* KeyFI;
	Classes::TList* Fields;
	bool Exclusive;
	int FieldCount;
} ;
#pragma pack(pop)

class DELPHICLASS TVolgaCursor;
typedef void __fastcall (__closure *TCursorFilterEvent)(TVolgaCursor* Sender, PVolgaRecord pRec, bool 
	&Accept);

class DELPHICLASS TVolgaDataset;
typedef void __fastcall (__closure *TCallbackEvent)(TVolgaDataset* Sender, const int Percent);

typedef void __fastcall (__closure *TCursorCallbackEvent)(const int Percent);

class DELPHICLASS TVolgaBlobStream;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVolgaBlobStream : public Classes::TMemoryStream 
{
	typedef Classes::TMemoryStream inherited;
	
private:
	Db::TBlobField* FField;
	TVolgaDataset* FDataSet;
	int FFieldNo;
	bool FModified;
	void __fastcall ReadBlobData(void);
	
public:
	__fastcall TVolgaBlobStream(Db::TBlobField* Field, Db::TBlobStreamMode Mode);
	__fastcall virtual ~TVolgaBlobStream(void);
	virtual int __fastcall Write(const void *Buffer, int Count);
	void __fastcall Truncate(void);
};

#pragma pack(pop)

class DELPHICLASS TVolgaMasterLink;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVolgaMasterLink : public Db::TDetailDataLink 
{
	typedef Db::TDetailDataLink inherited;
	
private:
	TVolgaDataset* FDataSet;
	AnsiString FFieldNames;
	Classes::TList* FFields;
	Classes::TNotifyEvent FOnMasterChange;
	Classes::TNotifyEvent FOnMasterDisable;
	void __fastcall SetFieldNames(const AnsiString Value);
	
protected:
	virtual void __fastcall ActiveChanged(void);
	virtual void __fastcall CheckBrowseMode(void);
	virtual Db::TDataSet* __fastcall GetDetailDataSet(void);
	virtual void __fastcall LayoutChanged(void);
	virtual void __fastcall RecordChanged(Db::TField* Field);
	
public:
	__fastcall TVolgaMasterLink(TVolgaDataset* DataSet);
	__fastcall virtual ~TVolgaMasterLink(void);
	__property AnsiString FieldNames = {read=FFieldNames, write=SetFieldNames};
	__property Classes::TList* Fields = {read=FFields};
	__property Classes::TNotifyEvent OnMasterChange = {read=FOnMasterChange, write=FOnMasterChange};
	__property Classes::TNotifyEvent OnMasterDisable = {read=FOnMasterDisable, write=FOnMasterDisable};
		
};

#pragma pack(pop)

#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVolgaCursor : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TList* FData;
	Classes::TList* FFldInfo;
	char *FFieldLayout;
	int FFldLen;
	int FFldCount;
	int FRecSize;
	bool FPartialOpen;
	TCursorFilterEvent FFilterClause;
	AnsiString FNotes;
	TCursorCallbackEvent FOnCallback;
	bool __fastcall AddNewRecord(Classes::TStream* Stream, AnsiString &Msg);
	bool __fastcall InitFieldDefs(AnsiString &Msg);
	int __fastcall GetRecordCount(void);
	int __fastcall GetFieldCount(void);
	PVolgaField __fastcall GetFieldInfo(int Index);
	PVolgaRecord __fastcall GetData(int Index);
	bool __fastcall LoadStruFromStream(Classes::TStream* Stream, AnsiString &Msg, int &rec_count);
	void __fastcall CalcRecSize(PVolgaRecord pRec);
	int __fastcall CalcStreamSize(void);
	void __fastcall FillFieldLayout(void);
	
public:
	__fastcall TVolgaCursor(void);
	__fastcall virtual ~TVolgaCursor(void);
	void __fastcall CancelUpdates(void);
	void __fastcall Clear(bool WithFields);
	void __fastcall ClearBuf(char * RecBuf);
	void __fastcall ClearData(char * &RecBuf);
	void __fastcall CommitUpdates(void);
	void __fastcall CopyRecordBuf(char * SourceBuf, char * DestBuf);
	bool __fastcall CreateUndoCopy(PVolgaRecord pRec);
	bool __fastcall DeleteRecord(PVolgaRecord CurRec, AnsiString &Msg);
	PVolgaField __fastcall FindFieldInfo(const AnsiString Name);
	AnsiString __fastcall GetFieldText(PVolgaField FI, PVolgaRecord P, bool IsOld, bool YearFirst);
	bool __fastcall LoadFieldInfo(Classes::TStream* Stream, AnsiString &Msg);
	bool __fastcall LoadFromStream(Classes::TStream* Stream, AnsiString &Msg);
	bool __fastcall SaveRecord(char * Buf, PVolgaRecord CurRec, AnsiString &Msg);
	int __fastcall SaveToStream(Classes::TStream* AStream);
	void __fastcall SaveToFile(const AnsiString Fname, TVolgaSaveOptions Options, const AnsiString FieldNames
		, const bool IgnoreCase);
	void __fastcall Sort(const AnsiString FieldNames, const bool IgnoreCase);
	void __fastcall UndoRecord(PVolgaRecord pRec);
	__property int FieldCount = {read=GetFieldCount, nodefault};
	__property PVolgaField FieldInfo[int Index] = {read=GetFieldInfo};
	__property TCursorFilterEvent FilterClause = {read=FFilterClause, write=FFilterClause};
	__property bool PartialOpen = {read=FPartialOpen, write=FPartialOpen, nodefault};
	__property PVolgaRecord RecData[int Index] = {read=GetData};
	__property int RecordCount = {read=GetRecordCount, nodefault};
	__property int RecSize = {read=FRecSize, nodefault};
	__property TCursorCallbackEvent OnCallback = {read=FOnCallback, write=FOnCallback};
};

#pragma pack(pop)

class DELPHICLASS TVolgaDatabase;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVolgaDatabase : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	Classes::TList* FDSList;
	Classes::TList* FUpdated;
	AnsiString FDatabasePath;
	char FDateQuot;
	AnsiString FDateFormat;
	TVolgaDataset* __fastcall GetDataSet(int Index);
	int __fastcall GetDataSetCount(void);
	int __fastcall GetUpdatedCount(void);
	TVolgaDataset* __fastcall GetUpdatedDataSet(int Index);
	void __fastcall SetDatabasePath(const AnsiString Value);
	void __fastcall Close(void);
	
protected:
	void __fastcall Add(TVolgaDataset* DS);
	HIDESBASE void __fastcall Remove(TVolgaDataset* DS);
	void __fastcall AddUpdated(TVolgaDataset* DS);
	void __fastcall DeleteUpdated(TVolgaDataset* DS);
	
public:
	__fastcall virtual TVolgaDatabase(Classes::TComponent* AOwner);
	__fastcall virtual ~TVolgaDatabase(void);
	void __fastcall ApplyUpdates(TVolgaDataset* const * ADataSets, const int ADataSets_Size);
	void __fastcall CancelUpdates(TVolgaDataset* const * ADataSets, const int ADataSets_Size);
	__property int DataSetCount = {read=GetDataSetCount, nodefault};
	__property TVolgaDataset* DataSets[int Index] = {read=GetDataSet};
	__property int UpdatedCount = {read=GetUpdatedCount, nodefault};
	__property TVolgaDataset* UpdatedDataSets[int Index] = {read=GetUpdatedDataSet};
	
__published:
	__property AnsiString DatabasePath = {read=FDatabasePath, write=SetDatabasePath};
};

#pragma pack(pop)

#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVolgaDataset : public Db::TDataSet 
{
	typedef Db::TDataSet inherited;
	
private:
	Word FRecordSize;
	Word FRecBufSize;
	int FCurRec;
	Classes::TList* FSortList;
	AnsiString FOrigin;
	AnsiString FNotes;
	bool FReadOnly;
	bool FRecReadOnly;
	AnsiString FIndexFieldNames;
	AnsiString FRangeFieldNames;
	AnsiString FUniqueFieldNames;
	bool FLoadedBuf;
	bool FIsRanged;
	bool FPartialOpen;
	TVolgaRecord *FFiltRec;
	Classes::TList* FCloneList;
	TVolgaMasterLink* FMasterLink;
	Classes::TNotifyEvent FOnNeed;
	unsigned FLoadTime;
	int FLoadSize;
	TCallbackEvent FOnCallback;
	TVolgaSortOptions FSortOptions;
	TVolgaSaveOptions FSaveOptions;
	TVolgaDatabase* FDatabase;
	bool FIsSorted;
	Classes::TStream* FExternalStream;
	TKeyBuffer *FKeyBuffers[4];
	TKeyBuffer *FKeyBuffer;
	void __fastcall AllocKeyBuffers(void);
	void __fastcall FreeKeyBuffers(void);
	PKeyBuffer __fastcall InitKeyBuffer(TKeyIndex KeyIndex, AnsiString FieldNames);
	void __fastcall SetKeyFields(TKeyIndex KeyIndex, const System::TVarRec * Values, const int Values_Size
		)/* overload */;
	void __fastcall SetKeyFields(TKeyIndex KeyIndex, const AnsiString Values)/* overload */;
	int __fastcall GetKeyFieldCount(void);
	void __fastcall SetKeyFieldCount(int Value);
	void __fastcall CheckSetKeyMode(void);
	void __fastcall SetKeyBuffer(TKeyIndex KeyIndex, bool Clear);
	bool __fastcall SetCursorRange(void);
	bool __fastcall ResetCursorRange(void);
	bool __fastcall GetKeyExclusive(void);
	void __fastcall SetKeyExclusive(bool Value);
	int __fastcall GetIndexFieldCount(void);
	int __fastcall GetRangeFieldCount(void);
	Db::TField* __fastcall GetIndexField(int Index);
	void __fastcall SetIndexField(int Index, Db::TField* Value);
	void __fastcall SetReadOnly(bool value);
	int __fastcall GetFieldOffset(int Num);
	void __fastcall ModifyRec(char * Buf);
	void __fastcall InsertRec(char * Buf);
	void __fastcall SetIndexFieldNames(const AnsiString value);
	bool __fastcall AcceptRange(PVolgaRecord pRec);
	bool __fastcall InternalLocate(const AnsiString KeyFields, const Variant &KeyValues, Db::TLocateOptions 
		Options, const bool FromStart);
	bool __fastcall GetActiveRecBuf(char * &RecBuf);
	bool __fastcall GetNeedToSave(void);
	int __fastcall InternalFind(const int istart, bool Sorted);
	void __fastcall SetDataSource(Db::TDataSource* Value);
	AnsiString __fastcall GetMasterFields(void);
	void __fastcall SetMasterFields(const AnsiString Value);
	void __fastcall SetRangeFieldNames(const AnsiString Value);
	void __fastcall DoCallback(const int Percent);
	void __fastcall SetSortOptions(const TVolgaSortOptions Value);
	bool __fastcall FastSeek(const AnsiString Fn);
	int __fastcall GetCloneCount(void);
	void __fastcall CheckCursorOpen(void);
	AnsiString __fastcall GetVersion(void);
	void __fastcall SetVersion(const AnsiString Value);
	int __fastcall GetStreamSize(void);
	void __fastcall MoveInsertedToOrder(void);
	
protected:
	int FNeedToSave;
	TVolgaCursor* FCursor;
	virtual void __fastcall SetOrigin(const AnsiString Value);
	virtual void __fastcall SetDatabase(const TVolgaDatabase* Value);
	void __fastcall AddClone(TVolgaDataset* DS);
	void __fastcall RemoveClone(TVolgaDataset* DS);
	virtual void __fastcall InternalLoadData(void) = 0 ;
	virtual void __fastcall InternalApplyUpdates(void) = 0 ;
	virtual void __fastcall DestroyCursor(void) = 0 ;
	void __fastcall InternalLoad(Classes::TStream* Stream, bool Keep);
	virtual char * __fastcall AllocRecordBuffer(void);
	virtual void __fastcall FreeRecordBuffer(char * &Buffer);
	virtual void __fastcall ClearCalcFields(char * Buffer);
	virtual void __fastcall GetBookmarkData(char * Buffer, void * Data);
	virtual Db::TBookmarkFlag __fastcall GetBookmarkFlag(char * Buffer);
	virtual Db::TGetResult __fastcall GetRecord(char * Buffer, Db::TGetMode GetMode, bool DoCheck);
	virtual Word __fastcall GetRecordSize(void);
	virtual Db::TDataSource* __fastcall GetDataSource(void);
	virtual void __fastcall InternalAddRecord(void * Buffer, bool Append);
	virtual void __fastcall InternalClose(void);
	virtual void __fastcall InternalDelete(void);
	virtual void __fastcall InternalFirst(void);
	virtual void __fastcall InternalRefresh(void);
	virtual void __fastcall InternalGotoBookmark(void * Bookmark);
	virtual void __fastcall InternalHandleException(void);
	virtual void __fastcall InternalInitFieldDefs(void);
	virtual void __fastcall InternalInitRecord(char * Buffer);
	virtual void __fastcall InternalLast(void);
	virtual void __fastcall InternalOpen(void);
	virtual void __fastcall InternalPost(void);
	virtual void __fastcall InternalSetToRecord(char * Buffer);
	virtual bool __fastcall IsCursorOpen(void);
	virtual void __fastcall SetBookmarkFlag(char * Buffer, Db::TBookmarkFlag Value);
	virtual void __fastcall SetBookmarkData(char * Buffer, void * Data);
	virtual void __fastcall SetFieldData(Db::TField* Field, void * Buffer);
	virtual bool __fastcall GetCanModify(void);
	virtual int __fastcall GetRecordCount(void);
	virtual int __fastcall GetRecNo(void);
	virtual void __fastcall SetRecNo(int Value);
	virtual void __fastcall SetFiltered(bool Value);
	virtual void __fastcall DoOnNewRecord(void);
	virtual void __fastcall DoBeforeDelete(void);
	virtual void __fastcall DoBeforeInsert(void);
	virtual void __fastcall DoBeforeEdit(void);
	virtual void __fastcall InternalCancel(void);
	void __fastcall CheckMasterRange(void);
	void __fastcall MasterChanged(System::TObject* Sender);
	void __fastcall MasterDisabled(System::TObject* Sender);
	
public:
	__fastcall virtual TVolgaDataset(Classes::TComponent* AOwner);
	__fastcall virtual ~TVolgaDataset(void);
	virtual Classes::TStream* __fastcall CreateBlobStream(Db::TField* Field, Db::TBlobStreamMode Mode);
		
	virtual bool __fastcall GetFieldData(Db::TField* Field, void * Buffer)/* overload */;
	virtual bool __fastcall GetFieldData(int FieldNo, void * Buffer)/* overload */;
	virtual bool __fastcall BookmarkValid(void * Bookmark);
	virtual int __fastcall CompareBookmarks(void * Bookmark1, void * Bookmark2);
	virtual bool __fastcall Locate(const AnsiString KeyFields, const Variant &KeyValues, Db::TLocateOptions 
		Options);
	virtual Variant __fastcall Lookup(const AnsiString KeyFields, const Variant &KeyValues, const AnsiString 
		ResultFields);
	virtual Db::TUpdateStatus __fastcall UpdateStatus(void);
	virtual void __fastcall ApplyUpdates(void);
	virtual void __fastcall CancelUpdates(void);
	virtual void __fastcall CommitUpdates(void);
	void __fastcall CopyRecord(void);
	void __fastcall EmptyTable(void);
	bool __fastcall ExistField(const AnsiString Fn);
	AnsiString __fastcall GetDescription(const AnsiString FieldName);
	void __fastcall SetDescription(const AnsiString FieldName, const AnsiString descr);
	AnsiString __fastcall GetDefaultValue(const AnsiString FieldName);
	void __fastcall SetDefaultValue(const AnsiString FieldName, const AnsiString value);
	Extended __fastcall GetSum(const AnsiString FieldName);
	bool __fastcall Find(const AnsiString KeyFields, const System::TVarRec * KeyValues, const int KeyValues_Size
		, const bool FromFirstRec);
	bool __fastcall FindTab(const AnsiString KeyFields, const AnsiString KeyValues, const bool FromFirstRec
		);
	AnsiString __fastcall GetTabValues(const AnsiString KeyFields);
	void __fastcall GotoCurrent(TVolgaDataset* DS);
	bool __fastcall Like(const AnsiString KeyFields, const AnsiString KeyValues, bool AtStartPos, bool 
		FromFirstRec);
	void __fastcall SaveToFile(const AnsiString FileName);
	void __fastcall SetRange(const System::TVarRec * StartValues, const int StartValues_Size, const System::TVarRec 
		* EndValues, const int EndValues_Size)/* overload */;
	void __fastcall SetRange(const AnsiString StartValues, const AnsiString EndValues)/* overload */;
	void __fastcall SortRecords(bool ToFirst);
	void __fastcall SetListOfFields(const AnsiString KeyFields, const System::TVarRec * KeyValues, const 
		int KeyValues_Size);
	bool __fastcall FindKey(const System::TVarRec * KeyValues, const int KeyValues_Size);
	void __fastcall EditKey(void);
	bool __fastcall GotoKey(void);
	void __fastcall SetKey(void);
	void __fastcall ApplyRange(void);
	void __fastcall CancelRange(void);
	void __fastcall EditRangeEnd(void);
	void __fastcall EditRangeStart(void);
	void __fastcall SetRangeEnd(void);
	void __fastcall SetRangeStart(void);
	__property int KeyFieldCount = {read=GetKeyFieldCount, write=SetKeyFieldCount, nodefault};
	__property bool KeyExclusive = {read=GetKeyExclusive, write=SetKeyExclusive, nodefault};
	__property int IndexFieldCount = {read=GetIndexFieldCount, nodefault};
	__property int RangeFieldCount = {read=GetRangeFieldCount, nodefault};
	__property Db::TField* IndexFields[int Index] = {read=GetIndexField, write=SetIndexField};
	__property int CloneCount = {read=GetCloneCount, nodefault};
	__property bool IsRanged = {read=FIsRanged, nodefault};
	__property int LoadSize = {read=FLoadSize, nodefault};
	__property unsigned LoadTime = {read=FLoadTime, nodefault};
	__property bool NeedToSave = {read=GetNeedToSave, nodefault};
	__property AnsiString Origin = {read=FOrigin, write=SetOrigin};
	__property bool RecReadOnly = {read=FRecReadOnly, write=FRecReadOnly, nodefault};
	__property int StreamSize = {read=GetStreamSize, nodefault};
	__property Bof ;
	__property Bookmark ;
	__property DefaultFields ;
	__property Designer ;
	__property Eof ;
	__property FieldCount ;
	__property Fields ;
	__property FieldValues ;
	__property Found ;
	__property Modified ;
	__property RecordCount ;
	__property State ;
	
__published:
	__property TVolgaDatabase* Database = {read=FDatabase, write=SetDatabase};
	__property AnsiString IndexFieldNames = {read=FIndexFieldNames, write=SetIndexFieldNames};
	__property AnsiString MasterFields = {read=GetMasterFields, write=SetMasterFields};
	__property Db::TDataSource* MasterSource = {read=GetDataSource, write=SetDataSource};
	__property AnsiString Notes = {read=FNotes, write=FNotes};
	__property bool PartialOpen = {read=FPartialOpen, write=FPartialOpen, default=0};
	__property AnsiString RangeFieldNames = {read=FRangeFieldNames, write=SetRangeFieldNames};
	__property bool ReadOnly = {read=FReadOnly, write=SetReadOnly, default=0};
	__property TVolgaSaveOptions SaveOptions = {read=FSaveOptions, write=FSaveOptions, default=0};
	__property TVolgaSortOptions SortOptions = {read=FSortOptions, write=SetSortOptions, default=0};
	__property AnsiString UniqueFieldNames = {read=FUniqueFieldNames, write=FUniqueFieldNames};
	__property AnsiString Version = {read=GetVersion, write=SetVersion};
	__property Active ;
	__property AutoCalcFields ;
	__property Filtered ;
	__property AfterCancel ;
	__property AfterClose ;
	__property AfterDelete ;
	__property AfterEdit ;
	__property AfterInsert ;
	__property AfterOpen ;
	__property AfterPost ;
	__property AfterScroll ;
	__property BeforeCancel ;
	__property BeforeClose ;
	__property BeforeDelete ;
	__property BeforeEdit ;
	__property BeforeInsert ;
	__property BeforeOpen ;
	__property BeforePost ;
	__property BeforeScroll ;
	__property OnCalcFields ;
	__property OnFilterRecord ;
	__property OnNewRecord ;
	__property Classes::TNotifyEvent OnNeedToSaveChange = {read=FOnNeed, write=FOnNeed};
	__property TCallbackEvent OnCallback = {read=FOnCallback, write=FOnCallback};
};

#pragma pack(pop)

class DELPHICLASS TVolgaTable;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVolgaTable : public TVolgaDataset 
{
	typedef TVolgaDataset inherited;
	
private:
	AnsiString FTableName;
	TVolgaLoadMode FLoadMode;
	bool FStoreDefs;
	TVolgaDataset* FCloneDS;
	void __fastcall SetTableName(const AnsiString value);
	void __fastcall SetLoadMode(TVolgaLoadMode value);
	void __fastcall SetCloneDS(TVolgaDataset* value);
	bool __fastcall FieldDefsStored(void);
	void __fastcall InternalLoadByClearMode(void);
	void __fastcall InternalLoadFromFile(void);
	void __fastcall InternalLoadFromCursor(void);
	AnsiString __fastcall PrepareLayoutStr(Db::TFieldDefs* FD);
	AnsiString __fastcall GetFullTableName(void);
	
protected:
	virtual void __fastcall SetDatabase(const TVolgaDatabase* Value);
	virtual void __fastcall DefChanged(System::TObject* Sender);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	virtual void __fastcall InternalLoadData(void);
	virtual void __fastcall InternalApplyUpdates(void);
	virtual void __fastcall InternalClose(void);
	virtual void __fastcall DestroyCursor(void);
	
public:
	__fastcall virtual TVolgaTable(Classes::TComponent* AOwner);
	int __fastcall BatchMove(Db::TDataSet* ASource, TVolgaBatchMode AMode);
	virtual void __fastcall CancelUpdates(void);
	virtual void __fastcall CommitUpdates(void);
	void __fastcall CreateTable(void);
	void __fastcall DeleteTable(void);
	void __fastcall LoadFromFile(const AnsiString Fn);
	void __fastcall LoadFromCursor(TVolgaDataset* CloneDB);
	void __fastcall RenameTable(const AnsiString NewTableName);
	
__published:
	__property TVolgaDataset* CloneDS = {read=FCloneDS, write=SetCloneDS};
	__property AnsiString TableName = {read=FTableName, write=SetTableName};
	__property TVolgaLoadMode LoadMode = {read=FLoadMode, write=SetLoadMode, default=0};
	__property FieldDefs  = {stored=FieldDefsStored};
	__property bool StoreDefs = {read=FStoreDefs, write=FStoreDefs, default=0};
public:
	#pragma option push -w-inl
	/* TVolgaDataset.Destroy */ inline __fastcall virtual ~TVolgaTable(void) { }
	#pragma option pop
	
};

#pragma pack(pop)

class DELPHICLASS TVolgaSession;
#pragma pack(push, 4)
class PASCALIMPLEMENTATION TVolgaSession : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	Classes::TList* FDatabases;
	TVolgaDatabase* __fastcall GetDatabase(int Index);
	int __fastcall GetDatabaseCount(void);
	
protected:
	void __fastcall Add(TVolgaDatabase* Database);
	void __fastcall Delete(TVolgaDatabase* Database);
	
public:
	__fastcall TVolgaSession(void);
	__fastcall virtual ~TVolgaSession(void);
	__property int DatabaseCount = {read=GetDatabaseCount, nodefault};
	__property TVolgaDatabase* Databases[int Index] = {read=GetDatabase};
	void __fastcall GetTableNames(const AnsiString DatabasePath, const AnsiString Pattern, bool Extensions
		, Classes::TStrings* List)/* overload */;
	void __fastcall GetTableNames(const TVolgaDatabase* Database, AnsiString Pattern, bool Extensions, 
		Classes::TStrings* List)/* overload */;
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE int MAXSLEN;
extern PACKAGE AnsiString StrFieldType[17];
extern PACKAGE int SIZEINT;
extern PACKAGE int SIZEINT64;
extern PACKAGE int SIZEDOUB;
extern PACKAGE int SIZECHAR;
extern PACKAGE int SIZEBOOL;
extern PACKAGE char FieldSeparator;
extern PACKAGE char RecordSeparator;
extern PACKAGE char Tabulator;
extern PACKAGE char Quote2;
extern PACKAGE char Quote1;
extern PACKAGE AnsiString RETURN;
extern PACKAGE TVolgaSession* VolgaDB;
extern PACKAGE int __fastcall _if(bool b, int a1, int a2)/* overload */;
extern PACKAGE AnsiString __fastcall _if(bool b, AnsiString a1, AnsiString a2)/* overload */;
extern PACKAGE AnsiString __fastcall vSpaceToChar(const AnsiString s, char p);
extern PACKAGE void __fastcall Split(const AnsiString s, const AnsiString delim, Classes::TStrings* 
	SplitArray);
extern PACKAGE AnsiString __fastcall GetUnicod(void);
extern PACKAGE AnsiString __fastcall GetUnicod10(void);
extern PACKAGE TVolgaFieldType __fastcall GetFldType(AnsiString ft)/* overload */;
extern PACKAGE AnsiString __fastcall GetFldType(TVolgaFieldType ft)/* overload */;
extern PACKAGE TVolgaFieldType __fastcall GetFldType(Db::TFieldType ft, int size)/* overload */;
extern PACKAGE Db::TFieldType __fastcall GetFldType2(AnsiString ft);
extern PACKAGE char __fastcall GetCharType(TVolgaFieldType ft, int ASize);
extern PACKAGE TVolgaCursor* __fastcall GetCursor(TVolgaDataset* Dataset);
extern PACKAGE bool __fastcall IsBufEmpty(char * Buffer, int size);
extern PACKAGE void __fastcall KillBuf(void * Buffer);
extern PACKAGE void __fastcall CopyLongString(char * BufSource, char * BufDest);
extern PACKAGE void __fastcall CopyBlobField(char * BufSource, char * BufDest);
extern PACKAGE int __fastcall CompareBuf(const char * key1, const char * key2, PVolgaField FI, bool 
	IgnoreCase);
extern PACKAGE int __fastcall CompareRec(char * Buf1, char * Buf2, Classes::TList* ListFI, int Count
	);
extern PACKAGE void __fastcall AssignBufFromStr(char * Buf, const AnsiString Value, PVolgaField FI);
	
extern PACKAGE void __fastcall AssignBufFromVar(char * Buf, const System::TVarRec &Value, PVolgaField 
	FI);
extern PACKAGE void __fastcall GetFldInfoList(TVolgaCursor* Sender, Classes::TList* List, const AnsiString 
	FieldNames);

}	/* namespace Volgatbl */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Volgatbl;
#endif
#pragma option pop	// -w-

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// VolgaTbl
